/* options.js */

import { getOptions, saveOptions, defaultOptions } from './storage.js';
import validatePrefix from './validatePrefix.js';

const getMessage = browser.i18n.getMessage;

const debug = false;
const inclWcagGl     = document.querySelector('input[id="options-incl-wcag-gl"]');
const noDelay        = document.querySelector('input[id="options-no-delay"]');
const promptForDelay = document.querySelector('input[id="options-prompt-for-delay"]');

const rulesetStrict  = document.querySelector('input[id="ARIA_STRICT"]');
const rulesetTrans   = document.querySelector('input[id="ARIA_TRANS"]');
const inclPassNa     = document.querySelector('input[id="options-incl-pass-na"]');

const exportPrompt   = document.querySelector('#options-export-prompt');
const exportCSV      = document.querySelector('#options-export-csv');
const exportJSON     = document.querySelector('#options-export-json');
const exportPrefix   = document.querySelector('#options-export-prefix');
const exportDate     = document.querySelector('#options-export-date');


const resetDefaults  = document.querySelector('button[id="options-reset-defaults"]');

function setFormLabels () {
  const optionsTitle            = document.querySelector('#options-title');
  const optionsViewsMenuLegend  = document.querySelector('#options-views-menu-legend');
  const optionsInclWcagGlLabel  = document.querySelector('#options-incl-wcag-gl-label');

  const optionsRerunEvaluationLegend = document.querySelector('#options-rerun-evaluation-legend');
  const optionsNoDelayLabel          = document.querySelector('#options-no-delay-label');
  const optionsPromptForDelayLabel   = document.querySelector('#options-prompt-for-delay-label');

  const optionsEvaluationHeading     = document.querySelector('#options-evaluation-heading');
  const optionsRulesetLegend         = document.querySelector('#options-ruleset-legend');
  const optionsRulesetStrictLabel    = document.querySelector('#options-ruleset-strict-label');
  const optionsRulesetTransLabel     = document.querySelector('#options-ruleset-trans-label');
  const optionsRuleResultsLegend     = document.querySelector('#options-rule-results-legend');
  const optionsInclPassNaLabel       = document.querySelector('#options-incl-pass-na-label');

  const optionsExportHeading         = document.querySelector('#options-export-heading');
  const optionsExportPromptLabel     = document.querySelector('#options-export-prompt-label');
  const optionsExportFormatLegend    = document.querySelector('#options-export-format-legend');
  const optionsExportCSVLabel        = document.querySelector('#options-export-csv-label');
  const optionsExportJSONLabel       = document.querySelector('#options-export-json-label');
  const optionsExportPrefixLabel     = document.querySelector('#options-export-prefix-label');
  const optionsExportDateLabel       = document.querySelector('#options-export-date-label');

  const optionsResetDefaults         = document.querySelector('#options-reset-defaults');

  optionsTitle.textContent            = getMessage('optionsTitle');
  optionsViewsMenuLegend.textContent  = getMessage('optionsViewsMenuLegend');
  optionsInclWcagGlLabel.textContent  = getMessage('optionsInclWcagGlLabel');
  optionsRerunEvaluationLegend.textContent = getMessage('optionsRerunEvaluationLegend');
  optionsNoDelayLabel.textContent          = getMessage('optionsNoDelayLabel');
  optionsPromptForDelayLabel.textContent   = getMessage('optionsPromptForDelayLabel');

  optionsEvaluationHeading.textContent     = getMessage('optionsEvaluationHeading');
  optionsRulesetLegend.textContent         = getMessage('optionsRulesetLegend');
  optionsRulesetStrictLabel.textContent    = getMessage('optionsRulesetStrictLabel');
  optionsRulesetTransLabel.textContent     = getMessage('optionsRulesetTransLabel');
  optionsRuleResultsLegend.textContent     = getMessage('optionsRuleResultsLegend');
  optionsInclPassNaLabel.textContent       = getMessage('optionsInclPassNaLabel');

  optionsExportHeading.textContent      = getMessage('optionsExportHeading');
  optionsExportPromptLabel.textContent  = getMessage('optionsExportPrompt');
  optionsExportFormatLegend.textContent = getMessage('optionsExportFormatLegend');
  optionsExportCSVLabel.textContent     = getMessage('optionsExportCSVLabel');
  optionsExportJSONLabel.textContent    = getMessage('optionsExportJSONLabel');
  optionsExportPrefixLabel.textContent  = getMessage('optionsExportPrefixLabel');
  optionsExportDateLabel.textContent    = getMessage('optionsExportIncludeDate');




  optionsResetDefaults.textContent         = getMessage('optionsResetDefaults');
}

// Save user options selected in form and display message

function saveFormOptions (e) {
  e.preventDefault();

  const options = {
    rulesetId: (rulesetStrict.checked ? 'ARIA_STRICT' : 'ARIA_TRANS'),
    viewsMenuIncludeGuidelines: inclWcagGl.checked,

    rerunDelayEnabled: promptForDelay.checked,
    resultsIncludePassNa: inclPassNa.checked,

    exportFormat: (exportCSV.checked ? 'CSV' : 'JSON'),
    filenamePrefix: validatePrefix(exportPrefix.value),
    includeDate:    exportDate.checked,
    includeTime:    exportDate.checked,
    promptForExportOptions: exportPrompt.checked

  }

  if (debug) console.log(options);
  saveOptions(options);
}

// Update HTML form values based on user options saved in storage.sync

function updateForm (options) {
  // Set form element values and states
  inclWcagGl.checked     = options.viewsMenuIncludeGuidelines;
  noDelay.checked        = !options.rerunDelayEnabled;
  promptForDelay.checked = options.rerunDelayEnabled;
  rulesetStrict.checked  = options.rulesetId === 'ARIA_STRICT';
  rulesetTrans.checked   = options.rulesetId === 'ARIA_TRANS';
  inclPassNa.checked     = options.resultsIncludePassNa;

  exportPrompt.checked   = options.promptForExportOptions;
  exportCSV.checked      = options.exportFormat === 'CSV';
  exportJSON.checked     = options.exportFormat === 'JSON';
  exportPrefix.value     = validatePrefix(options.filenamePrefix);
  exportDate.checked     = options.includeDate;

}

function updateOptionsForm() {
  setFormLabels();
  getOptions().then(updateForm);
}

function saveDefaultOptions () {
  saveOptions(defaultOptions).then(getOptions).then(updateForm);
}

function onKeyupValidatePrefix () {
  let value = validatePrefix(exportPrefix.value);
  if (value !== exportPrefix.value) {
    if (exportPrefix.value >= 16) {
      console.log("[PrefixError]: Prefix can only be 16 characters");
    } else {
      console.log("[PrefixError]: Character not allowed");
    }
  }
  exportPrefix.value = value;
}

// Add event listeners for saving and restoring options

document.addEventListener('DOMContentLoaded', updateOptionsForm);
inclWcagGl.addEventListener('change', saveFormOptions);
noDelay.addEventListener('change', saveFormOptions);
promptForDelay.addEventListener('change', saveFormOptions);
rulesetStrict.addEventListener('change', saveFormOptions);
rulesetTrans.addEventListener('change', saveFormOptions);
inclPassNa.addEventListener('change', saveFormOptions);

exportPrompt.addEventListener('change', saveFormOptions);
exportCSV.addEventListener('change', saveFormOptions);
exportJSON.addEventListener('change', saveFormOptions);
exportPrefix.addEventListener('change', saveFormOptions);
exportPrefix.addEventListener('keyup', onKeyupValidatePrefix);
exportDate.addEventListener('change', saveFormOptions);

resetDefaults.addEventListener('click', saveDefaultOptions);

