/* infoScopes.js */

const template = document.createElement('template');
template.innerHTML = `

 <h3 class="rules" id="id-aria">
    Aria Versions
  </h3>
  <table class="table" aria-labelledby="id-aria">
    <tbody>
      <tr>
        <th class="text-start text-top term">
          ARIA 1.2
        </th>
        <td class="text-start">
          The <a href="https://www.w3.org/TR/wai-aria-1.2/">Accessible Rich Internet Applications 1.2</a> Specification was published in June 2023.
      </tr>
      <tr>
        <th class="text-start text-top term">
          ARIA 1.3
        </th>
        <td class="text-start">
          The <a href="https://www.w3.org/TR/wai-aria-1.3/">Accessible Rich Internet Applications 1.2</a> is the current working draft under development.
        </td>
      </tr>
    </tbody>
  </table>
`;

export default class AriaVersions extends HTMLElement {
  constructor () {

    super();
    this.attachShadow({ mode: 'open' });

    // Use external CSS stylesheet
    let link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', './info-dialog/infoDialogContent.css');
    this.shadowRoot.appendChild(link);

    // Add DOM tree from template
    this.shadowRoot.appendChild(template.content.cloneNode(true));
  }
}

